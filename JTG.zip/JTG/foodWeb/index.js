const prev = document.querySelector('.prev');
const next = document.querySelector('.next');
const items = document.querySelector('.items');

prev.addEventListener('click', () => {
  items.scrollBy({ left: -200, behavior: 'smooth' });
});

next.addEventListener('click', () => {
  items.scrollBy({ left: 200, behavior: 'smooth' });
});
var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];

// Function to open the modal
function openModal() {
  modal.style.display = "block";
}

// Function to close the modal
function closeModal() {
  modal.style.display = "none";
}

// Close the modal when the user clicks on the close button
span.onclick = function() {
  closeModal();
}

// Close the modal if the user clicks outside of it
window.onclick = function(event) {
  if (event.target == modal) {
    closeModal();
  }
}
function showCartEmptyDialog() {
  document.getElementById("cartEmptyDialog").style.display = "block";
}

function closeCartEmptyDialog() {
  document.getElementById("cartEmptyDialog").style.display = "none";
}